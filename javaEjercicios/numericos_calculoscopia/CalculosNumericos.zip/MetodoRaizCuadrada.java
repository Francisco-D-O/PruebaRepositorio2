package numericos_calculos;

public class MetodoRaizCuadrada {
	
	public static double calcularRaizCuadra (double valorR) {
		
	
		return Math.sqrt(valorR);
	}
}

