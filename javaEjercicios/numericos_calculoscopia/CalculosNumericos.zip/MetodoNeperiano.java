package numericos_calculos;



public class MetodoNeperiano {
	
	
	public static double calcularNeperiano(double valor)  {
		
		
		return Math.log(valor);
	}

}
